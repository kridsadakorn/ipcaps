library(testthat)

test_check("IPCAPS")
