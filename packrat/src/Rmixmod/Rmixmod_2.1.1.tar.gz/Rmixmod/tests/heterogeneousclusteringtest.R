library(Rmixmod)
data(heterodata)
out<-mixmodCluster(heterodata[-1],2)
